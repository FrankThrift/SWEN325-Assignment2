import React, { Component } from 'react';
import {
  Alert,
  AppRegistry,
  Button,
  Text,
  TextInput,
  TouchableHighlight,
  View,
} from 'react-native';


export default class SummonerScreen extends Component {

  render() {

    return(
      <View style = {Style.listItem}>

      </View>
    );
  }
}
