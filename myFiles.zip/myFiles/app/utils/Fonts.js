export const Fonts = {
  FrizQuadrataTTRegular: 'Friz Quadrata TT Regular'
}
